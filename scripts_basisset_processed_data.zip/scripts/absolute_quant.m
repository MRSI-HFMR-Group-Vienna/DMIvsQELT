
%% QELT Data absolute quantification 3T
TE=0.8e-3;
TR=960e-3;
T1_glx_GM=1.27;
T1_glx_WM=1.17;

T2_glx_GM=201e-3;
T2_glx_WM=198e-3;

T1_tCr_GM=1.46;
T1_tCr_WM=1.24;

T2_tCr_GM=134e-3;
T2_tCr_WM=148e-3;

R_tCr_GM=exp(-TE/T2_tCr_GM)*(1-exp(-TR/T1_tCr_GM));
R_tCr_WM=exp(-TE/T2_tCr_WM)*(1-exp(-TR/T1_tCr_WM));

R_glx_GM=exp(-TE/T2_glx_GM)*(1-exp(-TR/T1_glx_GM));
R_glx_WM=exp(-TE/T2_glx_WM)*(1-exp(-TR/T1_glx_WM));

%R_glc_GM=exp(-TE/T2_glc_GM)*(1-exp(-TR/T1_glc_GM));
%R_glc_WM=exp(-TE/T2_glc_WM)*(1-exp(-TR/T1_glc_WM));

fGM=niftiread('masks_pve_1.nii');
%fGM=fGM.img();
fWM=niftiread('masks_pve_2.nii');
%make dWM a ratio of GM absolute concentration (7.5mM) 
%fWM=fWM.img();
%no tCr in CSF
%fCSF=load_untouch_nii('masks_pve_0.nii');
%fCSF=fCSF.img();

fac_GM_WM=5.7/7.5;
GM_tCr_mM=7.5;
% fn: old map without mM 
% abs_glx_tCr_factor=(fGM*R_tCr_GM+fWM*R_tCr_WM)./(fGM*R_glx_GM+fWM*R_glx_WM);
abs_glx_tCr_factor=((fGM*R_tCr_GM+fWM*R_tCr_WM*fac_GM_WM)./(fGM*R_glx_GM+fWM*R_glx_WM))*GM_tCr_mM;

abs_glx_tCr_factor(isinf(abs_glx_tCr_factor))=0;
abs_glx_tCr_factor(isnan(abs_glx_tCr_factor))=0;
abs_glx_tCr_factor(abs_glx_tCr_factor>10)=0;
header_magnitude=niftiinfo('magnitude.nii');
niftiwrite(abs_glx_tCr_factor,'abs_glx_tCr_factor.nii',header_magnitude);

%% use mincresample to scale image to csi grid
abs_glx_tCr=niftiread('abs_glx_tCr.nii');
for x=1:21
abs_glx_tCr(:,:,x)=medfilt2(abs_glx_tCr(:,:,x));
end
%abs_glx_tCr=abs_glx_tCr.img();
writeNPY(abs_glx_tCr,'abs_glx_tCr4_filt_mM.npy');

%% DMI data absolute quantification

TR=290e-3;
TE=1.51e-3;
%T1_D2O=350e-3;
T1_GM_D2O=320e-3;
T1_WM_D2O=290e-3;
T1_CSF_D2O=510-3;

T1_glx=139e-3;
T1_glc=67e-3;
%T2_D2O=30e-3;
T2_GM_D2O=32e-3;
T2_WM_D2O=30e-3;
T2_CSF_D2O=90e-3;


T2_glx=44e-3;
T2_glc=42e-3;

%R_dwater=exp(-TE/T2_D2O)*(1-exp(-TR/T1_D2O));
R_GM_dwater=exp(-TE/T2_GM_D2O)*(1-exp(-TR/T1_GM_D2O));
R_WM_dwater=exp(-TE/T2_WM_D2O)*(1-exp(-TR/T1_WM_D2O));
R_CSF_dwater=exp(-TE/T2_CSF_D2O)*(1-exp(-TR/T1_CSF_D2O));

R_dglx=exp(-TE/T2_glx)*(1-exp(-TR/T1_glx));
R_dglc=exp(-TE/T2_glc)*(1-exp(-TR/T1_glc));


mol_dwater=55.51e3*0.000156;

dGM=0.78;
dWM=0.65;
dCSF=0.97;



fGM=niftiread('masks_pve_1.nii');
%fGM=fGM.img();
fWM=niftiread('masks_pve_2.nii');
%fWM=fWM.img();
fCSF=niftiread('masks_pve_0.nii');
%fCSF=fCSF.img();
%Glx
abs_glx_factor=(fGM*dGM*R_GM_dwater+fWM*dWM*R_WM_dwater+fCSF*dCSF*R_CSF_dwater)./((1-fCSF)*R_dglx)*mol_dwater;
abs_glx_factor(abs_glx_factor==inf)=0;
abs_glx_factor(abs_glx_factor==nan)=0;
abs_glx_factor(abs_glx_factor>10)=0;
header_magnitude=niftiinfo('UNI_fn_mask.nii');
niftiwrite(abs_glx_factor,'abs_glx_factor.nii',header_magnitude);
%Glc
abs_glx_factor_glc=(fGM*dGM*R_GM_dwater+fWM*dWM*R_WM_dwater+fCSF*dCSF*R_CSF_dwater)./((1-fCSF)*R_dglc)*mol_dwater;
abs_glx_factor_glc(abs_glx_factor_glc==inf)=0;
abs_glx_factor_glc(abs_glx_factor_glc==nan)=0;
abs_glx_factor_glc(abs_glx_factor_glc>10)=0;
header_magnitude=niftiinfo('UNI_fn_mask.nii');
niftiwrite(abs_glx_factor_glc,'abs_glc_factor.nii',header_magnitude);


%%% use mincresample to scale image to csi grid
Glx_abs=niftiread('Glx_abs.nii');
% for x=1:14
% Glx_abs(:,:,x)=medfilt2(Glx_abs(:,:,x));
% end
writeNPY(Glx_abs,'Glx_abs_newwater_nofilt.npy');

%%% use mincresample to scale image to csi grid
Glc_abs=niftiread('Glc_abs.nii');
% for x=1:14
% Glc_abs(:,:,x)=medfilt2(Glc_abs(:,:,x));
% end
writeNPY(Glc_abs,'Glc_abs_newwater_nofilt.npy');

%% create abs maps QELT
header_3D=niftiinfo('maps/1/Orig/gl_u_o+gl_n_o_amp_map.nii');
mrsi_4D_abs=readNPY('mrsi_4D_abs_mM_QC.npy');
mrsi_4D_abs=permute(mrsi_4D_abs,[2 3 4 1]);
mrsi_4D_abs=single(mrsi_4D_abs);
niftiwrite(mrsi_4D_abs(:,:,:,1),'abs_maps/mM/QC/1.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,2),'abs_maps/mM/QC/2.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,3),'abs_maps/mM/QC/3.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,4),'abs_maps/mM/QC/4.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,5),'abs_maps/mM/QC/5.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,6),'abs_maps/mM/QC/6.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,7),'abs_maps/mM/QC/7.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,8),'abs_maps/mM/QC/8.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,9),'abs_maps/mM/QC/9.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,10),'abs_maps/mM/QC/10.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,11),'abs_maps/mM/QC/11.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,12),'abs_maps/mM/QC/12.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,13),'abs_maps/mM/QC/13.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,14),'abs_maps/mM/QC/14.nii',header_3D);


header_3D=niftiinfo('maps/1/Orig/gl_cbo_amp_map.nii');
mrsi_4D_abs=readNPY('mrsi_4D_glc6_tCr.npy');
%mrsi_4D_abs=permute(mrsi_4D_abs,[2 3 4 1]);
mrsi_4D_abs=single(mrsi_4D_abs);
niftiwrite(mrsi_4D_abs(:,:,:,1),'ratio_maps_paper/1.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,2),'ratio_maps_paper/2.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,3),'ratio_maps_paper/3.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,4),'ratio_maps_paper/4.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,5),'ratio_maps_paper/5.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,6),'ratio_maps_paper/6.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,7),'ratio_maps_paper/7.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,8),'ratio_maps_paper/8.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,9),'ratio_maps_paper/9.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,10),'ratio_maps_paper/10.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,11),'ratio_maps_paper/11.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,12),'ratio_maps_paper/12.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,13),'ratio_maps_paper/13.nii',header_3D);
niftiwrite(mrsi_4D_abs(:,:,:,14),'ratio_maps_paper/14.nii',header_3D);

niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,2)),'abs_maps/diff/1.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,3)),'abs_maps/diff/2.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,4)),'abs_maps/diff/3.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,5)),'abs_maps/diff/4.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,6)),'abs_maps/diff/5.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,7)),'abs_maps/diff/6.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,8)),'abs_maps/diff/7.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,9)),'abs_maps/diff/8.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,10)),'abs_maps/diff/9.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,11)),'abs_maps/diff/10.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,12)),'abs_maps/diff/11.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,13)),'abs_maps/diff/12.nii',header_3D);
niftiwrite((mrsi_4D_abs(:,:,:,1)-mrsi_4D_abs(:,:,:,14)),'abs_maps/diff/13.nii',header_3D);

%% create abs maps DMI
header_3D=niftiinfo('maps/1/Orig/Glx_amp_map.nii');
mrsi_glx_4D_abs=readNPY('mrsi_glx_4D_abs.npy');
mrsi_glx_4D_abs=permute(mrsi_glx_4D_abs,[2 3 4 1]);
mrsi_glx_4D_abs=single(mrsi_glx_4D_abs);

mrsi_glc_4D_abs=readNPY('mrsi_glc_4D_abs_corrected.npy');
mrsi_glc_4D_abs=permute(mrsi_glc_4D_abs,[2 3 4 1]);
mrsi_glc_4D_abs=single(mrsi_glc_4D_abs);

niftiwrite(mrsi_glc_4D_abs(:,:,:,1),'abs_maps/QC/glc_1.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,2),'abs_maps/QC/glc_2.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,3),'abs_maps/QC/glc_3.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,4),'abs_maps/QC/glc_4.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,5),'abs_maps/QC/glc_5.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,6),'abs_maps/QC/glc_6.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,7),'abs_maps/QC/glc_7.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,8),'abs_maps/QC/glc_8.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,9),'abs_maps/QC/glc_9.nii',header_3D);
niftiwrite(mrsi_glc_4D_abs(:,:,:,10),'abs_maps/QC/glc_10.nii',header_3D);


niftiwrite(mrsi_glx_4D_abs(:,:,:,1),'abs_maps/QC/glx_1.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,2),'abs_maps/QC/glx_2.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,3),'abs_maps/QC/glx_3.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,4),'abs_maps/QC/glx_4.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,5),'abs_maps/QC/glx_5.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,6),'abs_maps/QC/glx_6.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,7),'abs_maps/QC/glx_7.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,8),'abs_maps/QC/glx_8.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,9),'abs_maps/QC/glx_9.nii',header_3D);
niftiwrite(mrsi_glx_4D_abs(:,:,:,10),'abs_maps/QC/glx_10.nii',header_3D);

%% QELT Data absolute quantification 7T
TE=1.3e-3;
TR=320e-3;
T1_glx_GM=1.62;
T1_glx_WM=1.75;

T2_glx_GM=57e-3;
T2_glx_WM=57e-3;

T1_tCr_GM=1.74;
T1_tCr_WM=1.78;

T2_tCr_GM=121e-3;
T2_tCr_WM=121e-3;

R_tCr_GM=exp(-TE/T2_tCr_GM)*(1-exp(-TR/T1_tCr_GM));
R_tCr_WM=exp(-TE/T2_tCr_WM)*(1-exp(-TR/T1_tCr_WM));

R_glx_GM=exp(-TE/T2_glx_GM)*(1-exp(-TR/T1_glx_GM));
R_glx_WM=exp(-TE/T2_glx_WM)*(1-exp(-TR/T1_glx_WM));

fGM=niftiread('masks_pve_1.nii');
%fGM=fGM.img();
fWM=niftiread('masks_pve_2.nii');
%fWM=fWM.img();
%no tCr in CSF
%fCSF=load_untouch_nii('masks_pve_0.nii');
%fCSF=fCSF.img();
abs_glx_tCr_factor=(fGM*R_tCr_GM+fWM*R_tCr_WM)./(fGM*R_glx_GM+fWM*R_glx_WM);
abs_glx_tCr_factor(isinf(abs_glx_tCr_factor))=0;
abs_glx_tCr_factor(isnan(abs_glx_tCr_factor))=0;
abs_glx_tCr_factor(abs_glx_tCr_factor>10)=0;
header_magnitude=niftiinfo('magnitude.nii');
niftiwrite(abs_glx_tCr_factor,'abs_glx_tCr_factor.nii',header_magnitude);

%% use mincresample to scale image to csi grid
abs_glx_tCr=niftiread('abs_glx_tCr.nii');
for x=1:23
abs_glx_tCr(:,:,x)=medfilt2(abs_glx_tCr(:,:,x));
end
%abs_glx_tCr=abs_glx_tCr.img();
writeNPY(abs_glx_tCr,'abs_glx_tCr.npy');

GM=niftiread('GM_mask.nii');
WM=niftiread('WM_mask.nii');
GM(GM<0.8)=0;
GM(GM>0.8)=1;
GM(GM<0.79)=0;
WM(WM<0.8)=0;
WM(WM>0.8)=1;
WM(WM<0.79)=0;
writeNPY(GM,'GM_mask.npy');
writeNPY(WM,'WM_mask.npy');

mask=niftiread('../mask.nii');
writeNPY(mask,'mask.npy');
