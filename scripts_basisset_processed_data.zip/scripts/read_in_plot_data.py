#!/Library/Frameworks/Python.framework/Versions/3.10/bin/python3




import numpy as np
import matplotlib.pyplot as plt
from optparse import OptionParser
from scipy.optimize import curve_fit
from scipy import stats

import os

#os.chdir('/data/fniess/nmr/7T/mv_svs/')


def exp_decrease(t,m0,tau,const):
    m = m0 * np.exp(-t/tau) + const
    return m
    
    
def exp_increase(t,m0,tau,d,const):
    m = m0 * (1-d*np.exp(-t/tau)) + const
    return m    

def exp_increaseinv(t,m0,tau,d,const):
    m = m0 * np.exp(t/tau) + const
    return m  

def fit(function,time,signals,param):
        
        try:
            popt, pcov = curve_fit(function, time, signals, param)
            perr = np.sqrt(np.diag(pcov))
            return [popt, perr]
        except:
            return [[0,0,0],[0,0,0]]
            
        
######## Read in Subjects Folder

# GM_glx_1H=np.load('GM_glx_o_all_points.npy')
# WM_glx_1H=np.load('WM_glx_o_all_points.npy')

# GM_tCr_1H=np.load('GM_tCr_all_points.npy')
# WM_tCr_1H=np.load('WM_tCr_all_points.npy')

# subject_time_1H=np.arange(0,60.19999999999999,4.3);




############################################### Direct 2H MRSI 7T





GM_glx_au_2H_all=[]
WM_glx_au_2H_all=[]

GM_glx_abs_2H_all=[]
WM_glx_abs_2H_all=[]

GM_glc_abs_2H_all=[]
WM_glc_abs_2H_all=[]

GM_water_2H_all=[]
WM_water_2H_all=[]


GM_glx_sd_2H_all=[]
WM_glx_sd_2H_all=[]

GM_WM_glx_sd_2H_all=[]

GM_glc_sd_2H_all=[]
WM_glc_sd_2H_all=[]

GM_WM_glc_sd_2H_all=[]

GM_water_sd_2H_all=[]
WM_water_sd_2H_all=[]

GM_WM_water_sd_2H_all=[]

GM_DMI_SNR_all=[]
WM_DMI_SNR_all=[]

GM_m_glx_2H_count=[]
WM_m_glx_2H_count=[]

GM_glx_2H_count=[]
WM_glx_2H_count=[]

GM_m_glc_2H_count=[]
WM_m_glc_2H_count=[]

GM_glc_2H_count=[]
WM_glc_2H_count=[]

subjects_DMI=[] 
subjects_DMI.append('Subject_01'); 
subjects_DMI.append('Subject_02'); 
subjects_DMI.append('Subject_03'); 
subjects_DMI.append('Subject_04'); 
subjects_DMI.append('Subject_05'); 



for i in np.arange(0,np.size(subjects_DMI)):
    os.chdir('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/'+subjects_DMI[i]+'/output/')         
    glx_2H=np.load('fmrsi_fit/Glx/mrsi_4D.npy');
    glc_2H=np.load('fmrsi_fit/Glc/mrsi_4D.npy')*2;
    
    glx_2H_org=np.load('fmrsi_fit/Glx/mrsi_4D.npy');
    glc_2H_org=np.load('fmrsi_fit/Glc/mrsi_4D.npy')*2;
    
    glx_2H_sd=np.load('Glx_sd_map.npy');
    glc_2H_sd=np.load('Glc_sd_map.npy');
    
    
    water_2H=np.load('fmrsi_fit/water/mrsi_4D.npy');
    water_2H_sd=np.load('water_sd_map.npy');

    
    ##### binary GM_mask Threshold 80%
    GM_mask_2H=np.load('GM_mask.npy'); 
    WM_mask_2H=np.load('WM_mask.npy');
    glx_abs=np.load('Glx_abs_newwater_nofilt.npy');
    glc_abs=np.load('Glc_abs_newwater_nofilt.npy');
    
    DMI_SNR=np.load('SNR.npy');
    
    glx_2H[np.isnan(glx_2H)]=0;
    glc_2H[np.isnan(glc_2H)]=0;
    water_2H[np.isnan(water_2H)]=0;
    

    #apply QC for CRLB threshold
    glx_2H[:,:,:,2:]=glx_2H[:,:,:,2:]*(glx_2H_sd[:,:,:,2:]<50);
    glc_2H[:,:,:,2:]=glc_2H[:,:,:,2:]*(glc_2H_sd[:,:,:,2:]<50);
    
    water_2H_avg=np.mean(water_2H[:,:,:,0:3],3);
    #water_2H_avg=water_2H[:,:,:,0];
    glx_water_2H=[glx_2H[:,:,:,x]/water_2H_avg for x in np.arange(0,np.size(glx_2H,3))];
    glx_water_2H=np.array(glx_water_2H)
    glx_water_2H[np.isinf(glx_water_2H)]=0;
    glx_water_2H[np.isnan(glx_water_2H)]=0;
    
    glc_water_2H=[glc_2H[:,:,:,x]/water_2H_avg for x in np.arange(0,np.size(glc_2H,3))];
    glc_water_2H=np.array(glc_water_2H)
    glc_water_2H[np.isinf(glc_water_2H)]=0;
    glc_water_2H[np.isnan(glc_water_2H)]=0;

    map_glx_water_abs=[glx_abs * glx_water_2H[x,:,:,:] for x in np.arange(0,np.size(glx_water_2H,0))];
    np.save('mrsi_glx_4D_abs.npy',map_glx_water_abs)
    
    map_glc_water_abs=[glc_abs * glc_water_2H[x,:,:,:] for x in np.arange(0,np.size(glc_water_2H,0))];
    np.save('mrsi_glc_4D_abs_corrected.npy',map_glc_water_abs)
    
    GM_glx_abs_2H=[np.sum(glx_water_2H[x,:,:,:] * glx_abs * GM_mask_2H)/np.count_nonzero(glx_water_2H[x,:,:,:] * glx_abs * GM_mask_2H) for x in np.arange(0,np.size(glx_2H,3))]
    WM_glx_abs_2H=[np.sum(glx_water_2H[x,:,:,:] * glx_abs * WM_mask_2H)/np.count_nonzero(glx_water_2H[x,:,:,:] * glx_abs * WM_mask_2H) for x in np.arange(0,np.size(glx_2H,3))]

    GM_glx_sd_2H=[np.sum(glx_2H_sd[:,:,:,x] * GM_mask_2H)/np.count_nonzero(glx_2H_sd[:,:,:,x] * GM_mask_2H) for x in np.arange(0,np.size(glx_2H_sd,3))]
    WM_glx_sd_2H=[np.sum(glx_2H_sd[:,:,:,x] * WM_mask_2H)/np.count_nonzero(glx_2H_sd[:,:,:,x] * WM_mask_2H) for x in np.arange(0,np.size(glx_2H_sd,3))]

    GM_WM_glx_sd_2H=[np.sum(glx_2H_sd[:,:,:,x] * (GM_mask_2H+WM_mask_2H))/np.count_nonzero(glx_2H_sd[:,:,:,x] * (GM_mask_2H+WM_mask_2H)) for x in np.arange(0,np.size(glx_2H_sd,3))]

    GM_glx_au_2H=[np.sum(glx_2H[:,:,:,x] * GM_mask_2H)/np.count_nonzero(glx_2H[:,:,:,x] * GM_mask_2H) for x in np.arange(0,np.size(glx_2H,3))]
    WM_glx_au_2H=[np.sum(glx_2H[:,:,:,x] * WM_mask_2H)/np.count_nonzero(glx_2H[:,:,:,x] * WM_mask_2H) for x in np.arange(0,np.size(glx_2H,3))]

    GM_water_au_2H=[np.sum(water_2H[:,:,:,x] * GM_mask_2H)/np.count_nonzero(water_2H[:,:,:,x] * GM_mask_2H) for x in np.arange(0,np.size(water_2H,3))]
    WM_water_au_2H=[np.sum(water_2H[:,:,:,x] * WM_mask_2H)/np.count_nonzero(water_2H[:,:,:,x] * WM_mask_2H) for x in np.arange(0,np.size(water_2H,3))]


    GM_glc_abs_2H=[np.sum(glc_water_2H[x,:,:,:] * glc_abs * GM_mask_2H)/np.count_nonzero(glc_water_2H[x,:,:,:] * glc_abs * GM_mask_2H) for x in np.arange(0,np.size(glc_2H,3))]
    WM_glc_abs_2H=[np.sum(glc_water_2H[x,:,:,:] * glc_abs * WM_mask_2H)/np.count_nonzero(glc_water_2H[x,:,:,:] * glc_abs * WM_mask_2H) for x in np.arange(0,np.size(glc_2H,3))]

    GM_glc_sd_2H=[np.sum(glc_2H_sd[:,:,:,x] * GM_mask_2H)/np.count_nonzero(glc_2H_sd[:,:,:,x] * GM_mask_2H) for x in np.arange(0,np.size(glc_2H,3))]
    WM_glc_sd_2H=[np.sum(glc_2H_sd[:,:,:,x] * WM_mask_2H)/np.count_nonzero(glc_2H_sd[:,:,:,x] * WM_mask_2H) for x in np.arange(0,np.size(glc_2H,3))]
    
    GM_WM_glc_sd_2H=[np.sum(glc_2H_sd[:,:,:,x] * (GM_mask_2H+WM_mask_2H))/np.count_nonzero(glc_2H_sd[:,:,:,x] * (GM_mask_2H+WM_mask_2H)) for x in np.arange(0,np.size(glc_2H,3))]
    
    GM_water_sd_2H=[np.sum(water_2H_sd[:,:,:,x] * GM_mask_2H)/np.count_nonzero(water_2H_sd[:,:,:,x] * GM_mask_2H) for x in np.arange(0,np.size(water_2H_sd,3))]
    WM_water_sd_2H=[np.sum(water_2H_sd[:,:,:,x] * WM_mask_2H)/np.count_nonzero(water_2H_sd[:,:,:,x] * WM_mask_2H) for x in np.arange(0,np.size(water_2H_sd,3))]
    
    GM_WM_water_sd_2H=[np.sum(water_2H_sd[:,:,:,x] * (GM_mask_2H+WM_mask_2H)   )/np.count_nonzero(water_2H_sd[:,:,:,x] * (GM_mask_2H+WM_mask_2H)) for x in np.arange(0,np.size(water_2H_sd,3))]
    
    GM_DMI_SNR=[np.sum(DMI_SNR[:,:,:,x] * GM_mask_2H)/np.count_nonzero(DMI_SNR[:,:,:,x] * GM_mask_2H) for x in np.arange(0,np.size(DMI_SNR,3))]
    WM_DMI_SNR=[np.sum(DMI_SNR[:,:,:,x] * WM_mask_2H)/np.count_nonzero(DMI_SNR[:,:,:,x] * WM_mask_2H) for x in np.arange(0,np.size(DMI_SNR,3))]
    


    GM_water_2H_all.append(GM_water_au_2H)
    WM_water_2H_all.append(WM_water_au_2H)

    GM_glx_abs_2H_all.append(GM_glx_abs_2H)
    WM_glx_abs_2H_all.append(WM_glx_abs_2H)

    GM_glx_au_2H_all.append(GM_glx_au_2H)
    WM_glx_au_2H_all.append(WM_glx_au_2H)

    GM_glc_abs_2H_all.append(GM_glc_abs_2H)
    WM_glc_abs_2H_all.append(WM_glc_abs_2H)
    
    GM_glx_sd_2H_all.append(GM_glx_sd_2H)
    WM_glx_sd_2H_all.append(WM_glx_sd_2H)

    GM_WM_glx_sd_2H_all.append(GM_WM_glx_sd_2H)
    
    GM_glc_sd_2H_all.append(GM_glc_sd_2H)
    WM_glc_sd_2H_all.append(WM_glc_sd_2H)
    
    GM_WM_glc_sd_2H_all.append(GM_WM_glc_sd_2H)
    
    GM_water_sd_2H_all.append(GM_water_sd_2H)
    WM_water_sd_2H_all.append(WM_water_sd_2H)
    
    GM_WM_water_sd_2H_all.append(GM_WM_water_sd_2H)
    
    GM_DMI_SNR_all.append(GM_DMI_SNR)
    WM_DMI_SNR_all.append(WM_DMI_SNR)
    
    
    GM_m_glx_2H_count.append(np.sum([np.count_nonzero(glx_2H[:,:,:,x] * GM_mask_2H) for x in np.arange(2,np.size(glx_2H,3))]))
    WM_m_glx_2H_count.append(np.sum([np.count_nonzero(glx_2H[:,:,:,x] * WM_mask_2H) for x in np.arange(2,np.size(glx_2H,3))]))
    
    GM_glx_2H_count.append(np.sum([np.count_nonzero(glx_2H_org[:,:,:,x] * GM_mask_2H) for x in np.arange(2,np.size(glx_2H_org,3))]))
    WM_glx_2H_count.append(np.sum([np.count_nonzero(glx_2H_org[:,:,:,x] * WM_mask_2H) for x in np.arange(2,np.size(glx_2H_org,3))]))
    
    GM_m_glc_2H_count.append(np.sum([np.count_nonzero(glc_2H[:,:,:,x] * GM_mask_2H) for x in np.arange(2,np.size(glc_2H,3))]))
    WM_m_glc_2H_count.append(np.sum([np.count_nonzero(glc_2H[:,:,:,x] * WM_mask_2H) for x in np.arange(2,np.size(glc_2H,3))]))
    
    GM_glc_2H_count.append(np.sum([np.count_nonzero(glc_2H_org[:,:,:,x] * GM_mask_2H) for x in np.arange(2,np.size(glc_2H_org,3))]))
    WM_glc_2H_count.append(np.sum([np.count_nonzero(glc_2H_org[:,:,:,x] * WM_mask_2H) for x in np.arange(2,np.size(glc_2H_org,3))]))
    
    
    os.chdir('../../')


######### END READING 2H MRSI DATA


subject_time_2H=[] ## New Subject Order

subject_time_2H.append(np.arange(0,59,6.62)+7)
subject_time_2H.append(np.arange(0,66.2,6.62)+7)
subject_time_2H.append(np.arange(0,66.2,6.62)+7)
subject_time_2H.append(np.arange(0,66.2,6.62)+7)
subject_time_2H.append(np.arange(0,66.2,6.62)+7)
######################## READ IN QELT DATA 3T (1HMRSI)




GM_glx_o_all_points=[]
WM_glx_o_all_points=[]
GM_glx_o_sd_all_points=[]
WM_glx_o_sd_all_points=[]

GM_WM_glx_o_sd_all=[]

GM_glx_n_all_points=[]
WM_glx_n_all_points=[]
GM_tCr_all_points=[]
WM_tCr_all_points=[]

GM_tCr_sd_all_points=[]
WM_tCr_sd_all_points=[]

GM_WM_tCr_sd_all=[]

GM_tNAA_all_points=[]
WM_tNAA_all_points=[]
GM_glx_o_less_20=[]
WM_glx_o_less_20=[]
GM_glx_n_less_20=[]
WM_glx_n_less_20=[]
GM_tCr_less_20=[]
WM_tCr_less_20=[]
GM_tNAA_less_20=[]
WM_tNAA_less_20=[]
GM_glx_abs_all=[]
WM_glx_abs_all=[]

GM_glx_abs_all_noaverage=[]
WM_glx_abs_all_noaverage=[]

GM_glx_tCr_all=[]
WM_glx_tCr_all=[]

GM_QELT_SNR=[]
WM_QELT_SNR=[]

GM_glc6_tCr_all=[]
WM_glc6_tCr_all=[]


GM_glc6_o_all_points=[]
WM_glc6_o_all_points=[]

GM_glc6_o_sd_all_points=[]
WM_glc6_o_sd_all_points=[]

GM_WM_glc6_o_sd_all=[]

GM_glc6_o_all_slopes=[]
WM_glc6_o_all_slopes=[]

GM_glc6_o_all_intercept=[]
WM_glc6_o_all_intercept=[]

GM_glc6_o_all_rvalue=[]
WM_glc6_o_all_rvalue=[]

GM_glc6_o_all_pvalue=[]
WM_glc6_o_all_pvalue=[]

### counting

GM_m_glx_o_count=[]
WM_m_glx_o_count=[]    

GM_glx_o_count=[]
WM_glx_o_count=[]    

GM_m_glc6_o_count=[]
WM_m_glc6_o_count=[]

GM_glc6_o_count=[]
WM_glc6_o_count=[]


subjects=[] 
subjects.append('Subject_01');
subjects.append('Subject_02'); 
subjects.append('Subject_03'); 
subjects.append('Subject_04'); 
subjects.append('Subject_05');




for i in np.arange(0,np.size(subjects)):

    os.chdir('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/3T_DEU/'+subjects[i]+'/output_MRSI/')         
    glx_o=np.load('constrained_combined/fmrsi_fit/gl_u_o+gl_n_o/mrsi_4D.npy');
    glx_n=np.load('constrained_combined/fmrsi_fit/gl_u_n+gl_n_n/mrsi_4D.npy');
    tCr=np.load('constrained_combined/fmrsi_fit/Cr+PCr/mrsi_4D.npy');
    tNAA=np.load('constrained_combined/fmrsi_fit/NAA+NAAG/mrsi_4D.npy');
    glc6_o=np.load('glc6_combined/fmrsi_fit/gl_cbo/mrsi_4D.npy')
    
   # abs_glx_tCr=np.load('constrained_combined/abs_glx_tCr4_nofilt.npy')
    
    abs_glx_tCr_mM=np.load('constrained_combined/abs_glx_tCr4_nofilt_mM.npy')
    
    
    zero_phase=np.load('constrained_combined/zero_pha.npy');
    tCr_sd_map=np.load('constrained_combined/tCr_sd_map.npy');
    tNAA_sd_map=np.load('constrained_combined/tNAA_sd_map.npy');
    Glx_o_sd_map=np.load('constrained_combined/Glx_o_sd_map.npy');
    Glx_n_sd_map=np.load('constrained_combined/Glx_n_sd_map.npy');
    Glc6_o_sd_map=np.load('glc6_combined/Glc6_o_sd_map.npy');

    Glc6_o_sd_map[Glc6_o_sd_map>900]=0;
    Glx_o_sd_map[Glx_o_sd_map>900]=0;
    FWHM=np.load('constrained_combined/FWHM.npy');
    SNR=np.load('constrained_combined/SNR.npy');
    mask_voi=np.load('constrained_combined/mask.npy')
    GM_mask=np.load('constrained_combined/GM_mask.npy');
    WM_mask=np.load('constrained_combined/WM_mask.npy');

    GM_mask=GM_mask*mask_voi;
    WM_mask=WM_mask*mask_voi;

    QC=(FWHM<0.1)*(SNR>15);
    time_real=np.arange(0,60.19999999999999,4.3);

    glx_o[np.isnan(glx_o)]=0;
    glx_n[np.isnan(glx_n)]=0;
    glc6_o[np.isnan(glc6_o)]=0;
    tCr[np.isnan(tCr)]=0;
    tNAA[np.isnan(tNAA)]=0;

    m_glx_o=glx_o*QC*(Glx_o_sd_map<20);
    m_glx_n=glx_n*QC*(Glx_n_sd_map<20);
    m_glc6_o=glc6_o*QC*(Glc6_o_sd_map<50);
    m_tCr=tCr*QC*(tCr_sd_map<20);
    m_NAA=tNAA*QC*(tNAA_sd_map<20);

    #### ratio to tCr
    m_glx_tCr=m_glx_o/m_tCr;
    m_glx_tCr[np.isnan(m_glx_tCr)]=0;
    m_glx_tCr[np.isinf(m_glx_tCr)]=0;
    
    m_glc6_tCr=m_glc6_o/m_tCr;
    m_glc6_tCr[np.isnan(m_glc6_tCr)]=0;
    m_glc6_tCr[np.isinf(m_glc6_tCr)]=0;
    
    
    # fn old abs map without mM
    #GM_glx_abs=[np.sum(m_glx_tCr[:,:,:,x] * abs_glx_tCr * mol_tCr_GM * GM_mask)/np.count_nonzero(m_glx_tCr[:,:,:,x] * abs_glx_tCr * mol_tCr_GM * GM_mask) for x in np.arange(0,np.size(m_glx_tCr,3))]
    #WM_glx_abs=[np.sum(m_glx_tCr[:,:,:,x] * abs_glx_tCr * mol_tCr_WM * WM_mask)/np.count_nonzero(m_glx_tCr[:,:,:,x] * abs_glx_tCr * mol_tCr_WM * WM_mask) for x in np.arange(0,np.size(m_glx_tCr,3))]

    GM_glx_abs=[np.sum(m_glx_tCr[:,:,:,x] * abs_glx_tCr_mM * GM_mask)/np.count_nonzero(m_glx_tCr[:,:,:,x] * abs_glx_tCr_mM * GM_mask) for x in np.arange(0,np.size(m_glx_tCr,3))]
    WM_glx_abs=[np.sum(m_glx_tCr[:,:,:,x] * abs_glx_tCr_mM * WM_mask)/np.count_nonzero(m_glx_tCr[:,:,:,x] * abs_glx_tCr_mM * WM_mask) for x in np.arange(0,np.size(m_glx_tCr,3))]

    GM_glx_abs_noaverage=[m_glx_tCr[:,:,:,x] * abs_glx_tCr_mM * GM_mask for x in np.arange(0,np.size(m_glx_tCr,3))]
    WM_glx_abs_noaverage=[m_glx_tCr[:,:,:,x] * abs_glx_tCr_mM * WM_mask for x in np.arange(0,np.size(m_glx_tCr,3))]

    GM_glx_tCr=[np.sum(m_glx_tCr[:,:,:,x] * GM_mask)/np.count_nonzero(m_glx_tCr[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_glx_tCr,3))]
    WM_glx_tCr=[np.sum(m_glx_tCr[:,:,:,x] * WM_mask)/np.count_nonzero(m_glx_tCr[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_glx_tCr,3))]
    
    GM_glc6_tCr=[np.sum(m_glc6_tCr[:,:,:,x] * GM_mask)/np.count_nonzero(m_glc6_tCr[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_glc6_tCr,3))]
    WM_glc6_tCr=[np.sum(m_glc6_tCr[:,:,:,x] * WM_mask)/np.count_nonzero(m_glc6_tCr[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_glc6_tCr,3))]
    
    map_glx_o_m=glx_o*(Glx_o_sd_map<20);
    map_glx_tCr=map_glx_o_m/tCr;
    map_glx_tCr[np.isnan(map_glx_tCr)]=0;
    map_glx_tCr[np.isinf(map_glx_tCr)]=0;

#### glucose ratio maps
    map_glc6_o_m=glc6_o*(Glc6_o_sd_map<50);
    map_glc6_tCr=map_glc6_o_m/tCr;
    map_glc6_tCr[np.isnan(map_glc6_tCr)]=0;
    map_glc6_tCr[np.isinf(map_glc6_tCr)]=0;

## fn: plot CRLBs GM/WM over time  and SNR

    GM_glx_o_sd=[np.sum(Glx_o_sd_map[:,:,:,x] * GM_mask)/np.count_nonzero(Glx_o_sd_map[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(Glx_o_sd_map,3))]
    WM_glx_o_sd=[np.sum(Glx_o_sd_map[:,:,:,x] * WM_mask)/np.count_nonzero(Glx_o_sd_map[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(Glx_o_sd_map,3))]

    GM_WM_glx_o_sd=[np.sum(Glx_o_sd_map[:,:,:,x] * (GM_mask+WM_mask))/np.count_nonzero(Glx_o_sd_map[:,:,:,x] * (GM_mask+WM_mask)) for x in np.arange(0,np.size(Glx_o_sd_map,3))]
    
    GM_glc6_o_sd=[np.sum(Glc6_o_sd_map[:,:,:,x] * GM_mask)/np.count_nonzero(Glc6_o_sd_map[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(Glc6_o_sd_map,3))]
    WM_glc6_o_sd=[np.sum(Glc6_o_sd_map[:,:,:,x] * WM_mask)/np.count_nonzero(Glc6_o_sd_map[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(Glc6_o_sd_map,3))]

    GM_WM_glc6_o_sd=[np.sum(Glc6_o_sd_map[:,:,:,x] * (GM_mask+WM_mask))/np.count_nonzero(Glc6_o_sd_map[:,:,:,x] * (GM_mask+WM_mask)) for x in np.arange(0,np.size(Glc6_o_sd_map,3))]
    
    GM_tCr_sd=[np.sum(tCr_sd_map[:,:,:,x] * GM_mask)/np.count_nonzero(tCr_sd_map[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(tCr_sd_map,3))]
    WM_tCr_sd=[np.sum(tCr_sd_map[:,:,:,x] * WM_mask)/np.count_nonzero(tCr_sd_map[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(tCr_sd_map,3))]
    
    GM_WM_tCr_sd=[np.sum(tCr_sd_map[:,:,:,x] * (GM_mask+WM_mask))/np.count_nonzero(tCr_sd_map[:,:,:,x] * (GM_mask+WM_mask)) for x in np.arange(0,np.size(tCr_sd_map,3))]

    GM_SNR=[np.sum(SNR[:,:,:,x] * GM_mask)/np.count_nonzero(SNR[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(SNR,3))]
    WM_SNR=[np.sum(SNR[:,:,:,x] * WM_mask)/np.count_nonzero(SNR[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(SNR,3))]


    #map_glx_tCr_abs=[abs_glx_tCr * mol_tCr_GM*map_glx_tCr[:,:,:,x] for x in np.arange(0,14)];
    ## fn: mM already included in the updated abs_glx_tCr_mM
    map_glx_tCr_abs=[abs_glx_tCr_mM * map_glx_tCr[:,:,:,x] for x in np.arange(0,14)];
    np.save('constrained_combined/mrsi_4D_abs_mM_QC.npy',map_glx_tCr_abs)

    np.save('glc6_combined/mrsi_4D_glc6_tCr.npy',map_glc6_tCr)


    GM_glx_o_less_20.append(np.count_nonzero((Glx_o_sd_map[:,:,:,13]<20)*GM_mask))
    WM_glx_o_less_20.append(np.count_nonzero((Glx_o_sd_map[:,:,:,13]<20)*WM_mask))

    GM_glx_n_less_20.append(np.count_nonzero((Glx_n_sd_map[:,:,:,13]<20)*GM_mask))
    WM_glx_n_less_20.append(np.count_nonzero((Glx_n_sd_map[:,:,:,13]<20)*WM_mask))

    GM_tCr_less_20.append(np.count_nonzero((tCr_sd_map[:,:,:,13]<20)*GM_mask))
    WM_tCr_less_20.append(np.count_nonzero((tCr_sd_map[:,:,:,13]<20)*WM_mask))

    GM_tNAA_less_20.append(np.count_nonzero((tNAA_sd_map[:,:,:,13]<20)*GM_mask))
    WM_tNAA_less_20.append(np.count_nonzero((tNAA_sd_map[:,:,:,13]<20)*WM_mask))

    GM_glx_o=[np.sum(m_glx_o[:,:,:,x] * GM_mask)/np.count_nonzero(m_glx_o[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_glx_o,3))]
    WM_glx_o=[np.sum(m_glx_o[:,:,:,x] * WM_mask)/np.count_nonzero(m_glx_o[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_glx_o,3))]

    GM_glx_n=[np.sum(m_glx_n[:,:,:,x] * GM_mask)/np.count_nonzero(m_glx_n[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_glx_n,3))]
    WM_glx_n=[np.sum(m_glx_n[:,:,:,x] * WM_mask)/np.count_nonzero(m_glx_n[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_glx_n,3))]

    GM_glc6_o=[np.sum(m_glc6_o[:,:,:,x] * GM_mask)/np.count_nonzero(m_glc6_o[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_glc6_o,3))]
    WM_glc6_o=[np.sum(m_glc6_o[:,:,:,x] * WM_mask)/np.count_nonzero(m_glc6_o[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_glc6_o,3))]
        
    GM_tCr=[np.sum(m_tCr[:,:,:,x] * GM_mask)/np.count_nonzero(m_tCr[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_tCr,3))]
    WM_tCr=[np.sum(m_tCr[:,:,:,x] * WM_mask)/np.count_nonzero(m_tCr[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_tCr,3))]

    GM_tNAA=[np.sum(m_NAA[:,:,:,x] * GM_mask)/np.count_nonzero(m_NAA[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_NAA,3))]
    WM_tNAA=[np.sum(m_NAA[:,:,:,x] * WM_mask)/np.count_nonzero(m_NAA[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_NAA,3))]

    GM_glx_o_all_points.append(GM_glx_o)
    WM_glx_o_all_points.append(WM_glx_o)
    
    GM_glx_o_sd_all_points.append(GM_glx_o_sd)
    WM_glx_o_sd_all_points.append(WM_glx_o_sd)
    
    GM_WM_glx_o_sd_all.append(GM_WM_glx_o_sd)
    
    GM_glx_n_all_points.append(GM_glx_n)
    WM_glx_n_all_points.append(WM_glx_n)

    GM_glc6_o_all_points.append(GM_glc6_o)
    WM_glc6_o_all_points.append(WM_glc6_o)
    
    GM_glc6_o_sd_all_points.append(GM_glc6_o_sd)
    WM_glc6_o_sd_all_points.append(WM_glc6_o_sd)
    
    GM_WM_glc6_o_sd_all.append(GM_WM_glc6_o_sd)
    
    GM_tCr_all_points.append(GM_tCr)
    WM_tCr_all_points.append(WM_tCr)

    GM_tCr_sd_all_points.append(GM_tCr_sd)
    WM_tCr_sd_all_points.append(WM_tCr_sd)

    GM_WM_tCr_sd_all.append(GM_WM_tCr_sd)
    
    GM_QELT_SNR.append(GM_SNR)
    WM_QELT_SNR.append(WM_SNR)
    
    GM_tNAA_all_points.append(GM_tNAA)
    WM_tNAA_all_points.append(WM_tNAA)

    GM_glx_abs_all.append(GM_glx_abs)
    WM_glx_abs_all.append(WM_glx_abs)

    GM_glx_abs_all_noaverage.append(GM_glx_abs_noaverage)
    WM_glx_abs_all_noaverage.append(WM_glx_abs_noaverage)
    

    GM_glx_tCr_all.append(GM_glx_tCr)
    WM_glx_tCr_all.append(WM_glx_tCr)
    
    GM_glc6_tCr_all.append(GM_glc6_tCr)
    WM_glc6_tCr_all.append(WM_glc6_tCr)
    
    #### counting
    
    GM_m_glx_o_count.append(np.sum([np.count_nonzero(m_glx_o[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_glx_o,3))]))
    WM_m_glx_o_count.append(np.sum([np.count_nonzero(m_glx_o[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_glx_o,3))]))
    
    GM_glx_o_count.append(np.sum([np.count_nonzero(glx_o[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(glx_o,3))]))
    WM_glx_o_count.append(np.sum([np.count_nonzero(glx_o[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(glx_o,3))]))
    
    GM_m_glc6_o_count.append(np.sum([np.count_nonzero(m_glc6_o[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(m_glc6_o,3))]))
    WM_m_glc6_o_count.append(np.sum([np.count_nonzero(m_glc6_o[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(m_glc6_o,3))]))
    
    GM_glc6_o_count.append(np.sum([np.count_nonzero(glc6_o[:,:,:,x] * GM_mask) for x in np.arange(0,np.size(glc6_o,3))]))
    WM_glc6_o_count.append(np.sum([np.count_nonzero(glc6_o[:,:,:,x] * WM_mask) for x in np.arange(0,np.size(glc6_o,3))]))
    
    os.chdir('../../')



subject_time_1H=np.arange(0,59,4.22);

GM_glx_2H_linregs=[stats.linregress(subject_time_2H[x],GM_glx_abs_2H_all[x]) for x in np.arange(0,np.size(subjects_DMI))]
WM_glx_2H_linregs=[stats.linregress(subject_time_2H[x],WM_glx_abs_2H_all[x]) for x in np.arange(0,np.size(subjects_DMI))]

##### glx interpolation 
GM_glx_abs_2H_interpolated=[(subject_time_1H+7)*GM_glx_2H_linregs[x][0]+GM_glx_2H_linregs[x][1] for x in np.arange(0,np.size(subjects_DMI))]
WM_glx_abs_2H_interpolated=[(subject_time_1H+7)*WM_glx_2H_linregs[x][0]+WM_glx_2H_linregs[x][1] for x in np.arange(0,np.size(subjects_DMI))]

##### glc interpolation ##### Subject No1 has one time point less
GM_glc_2H_expfit=[]
GM_glc_2H_expfit.append(fit(exp_increase,subject_time_2H[0],GM_glc_abs_2H_all[0][0:9],[GM_glc_abs_2H_all[0][-1],20,1,0])[0])
[GM_glc_2H_expfit.append(fit(exp_increase,subject_time_2H[1],GM_glc_abs_2H_all[x],[GM_glc_abs_2H_all[x][-1],20,1,0])[0]) for x in np.arange(1,5)]
#GM_glc_2H_expfit.append(fit(exp_increase,subject_time_2H[4],GM_glc_abs_2H_all[4],[GM_glc_abs_2H_all[4][-1],20,1,0])[0])

WM_glc_2H_expfit=[]
WM_glc_2H_expfit.append(fit(exp_increase,subject_time_2H[0],WM_glc_abs_2H_all[0][0:9],[WM_glc_abs_2H_all[0][-1],20,1,0])[0])
[WM_glc_2H_expfit.append(fit(exp_increase,subject_time_2H[1],WM_glc_abs_2H_all[x],[WM_glc_abs_2H_all[x][-1],20,1,0])[0]) for x in np.arange(1,5)]
#WM_glc_2H_expfit.append(fit(exp_increase,subject_time_2H[4],WM_glc_abs_2H_all[4],[WM_glc_abs_2H_all[4][-1],20,1,0])[0])

#### Indivicual 1H glc6 exp fitting
GM_glc6_expfit_ind=[]
[GM_glc6_expfit_ind.append(fit(exp_decrease,subject_time_1H+7,GM_glc6_tCr_all[x],[GM_glc6_tCr_all[x][0],20,GM_glc6_tCr_all[x][13]])[0]) for x in np.arange(0,np.size(subjects))]
WM_glc6_expfit_ind=[]
[WM_glc6_expfit_ind.append(fit(exp_decrease,subject_time_1H+7,WM_glc6_tCr_all[x],[WM_glc6_tCr_all[x][0],20,WM_glc6_tCr_all[x][13]])[0]) for x in np.arange(0,np.size(subjects))]



##### glc interpolation
GM_glc_abs_2H_interpolated=[exp_increase(subject_time_1H+7,GM_glc_2H_expfit[x][0],GM_glc_2H_expfit[x][1],GM_glc_2H_expfit[x][2],GM_glc_2H_expfit[x][3]) for x in np.arange(0,np.size(subjects_DMI))]
WM_glc_abs_2H_interpolated=[exp_increase(subject_time_1H+7,WM_glc_2H_expfit[x][0],WM_glc_2H_expfit[x][1],WM_glc_2H_expfit[x][2],WM_glc_2H_expfit[x][3]) for x in np.arange(0,np.size(subjects_DMI))]

##### Subject No1 has one time point less
GM_glx_abs_2H_all[0].append(np.nan)
WM_glx_abs_2H_all[0].append(np.nan)

GM_glc_abs_2H_all[0].append(np.nan)
WM_glc_abs_2H_all[0].append(np.nan)

GM_water_2H_all[0].append(np.nan)
WM_water_2H_all[0].append(np.nan)

GM_glx_sd_2H_all[0].append(np.nan)
WM_glx_sd_2H_all[0].append(np.nan)

GM_WM_glx_sd_2H_all[0].append(np.nan)

GM_glc_sd_2H_all[0].append(np.nan)
WM_glc_sd_2H_all[0].append(np.nan)

GM_WM_glc_sd_2H_all[0].append(np.nan)

GM_water_sd_2H_all[0].append(np.nan)
WM_water_sd_2H_all[0].append(np.nan)

GM_WM_water_sd_2H_all[0].append(np.nan)

GM_DMI_SNR_all[0].append(np.nan)
WM_DMI_SNR_all[0].append(np.nan)

GM_glx_abs_2H_all=np.array(GM_glx_abs_2H_all)
WM_glx_abs_2H_all=np.array(WM_glx_abs_2H_all)

GM_glc_abs_2H_all=np.array(GM_glc_abs_2H_all)
WM_glc_abs_2H_all=np.array(WM_glc_abs_2H_all)

GM_glx_abs_avg=np.mean(GM_glx_abs_all,0)
WM_glx_abs_avg=np.mean(WM_glx_abs_all,0)

GM_glx_abs_2H_avg=np.nanmean(GM_glx_abs_2H_all,0)
WM_glx_abs_2H_avg=np.nanmean(WM_glx_abs_2H_all,0)

GM_glc_abs_2H_avg=np.nanmean(GM_glc_abs_2H_all,0)
WM_glc_abs_2H_avg=np.nanmean(WM_glc_abs_2H_all,0)


#### for data analysis

GM_glx_abs_drop_mean=np.mean([GM_glx_abs_all[x][0]-GM_glx_abs_all[x][13] for x in np.arange(0,np.size(subjects))])
WM_glx_abs_drop_mean=np.mean([WM_glx_abs_all[x][0]-WM_glx_abs_all[x][13] for x in np.arange(0,np.size(subjects))])

GM_glx_abs_drop_sd=np.std([GM_glx_abs_all[x][0]-GM_glx_abs_all[x][13] for x in np.arange(0,np.size(subjects))])
WM_glx_abs_drop_sd=np.std([WM_glx_abs_all[x][0]-WM_glx_abs_all[x][13] for x in np.arange(0,np.size(subjects))])

GM_glx_abs_2H_inc=np.nanmean([GM_glx_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])
WM_glx_abs_2H_inc=np.nanmean([WM_glx_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])

GM_glx_abs_2H_inc_sd=np.nanstd([GM_glx_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])
WM_glx_abs_2H_inc_sd=np.nanstd([WM_glx_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])


GM_glc_abs_2H_inc=np.nanmean([GM_glc_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])
WM_glc_abs_2H_inc=np.nanmean([WM_glc_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])

GM_glc_abs_2H_inc_sd=np.nanstd([GM_glc_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])
WM_glc_abs_2H_inc_sd=np.nanstd([WM_glc_abs_2H_all[x][-1] for x in np.arange(0,np.size(subjects_DMI))])


#### fn: linregs

GM_glx_linreg=stats.linregress(subject_time_1H+7,np.mean(GM_glx_abs_all,0))
WM_glx_linreg=stats.linregress(subject_time_1H+7,np.mean(WM_glx_abs_all,0))

GM_glx_linreg_individual=[stats.linregress(subject_time_1H+7,GM_glx_abs_all[x]) for x in np.arange(0,np.size(subjects))]
WM_glx_linreg_individual=[stats.linregress(subject_time_1H+7,WM_glx_abs_all[x]) for x in np.arange(0,np.size(subjects))]



###### fn: comparison wilcoxon and correlation
    
GM_QELT_glx_slopes=[GM_glx_linreg_individual[x][0]*(-1) for x in np.arange(0,np.size(subjects))]
WM_QELT_glx_slopes=[WM_glx_linreg_individual[x][0]*(-1) for x in np.arange(0,np.size(subjects))]

GM_DMI_glx_slopes=[GM_glx_2H_linregs[x][0] for x in np.arange(0,np.size(subjects))]
WM_DMI_glx_slopes=[WM_glx_2H_linregs[x][0] for x in np.arange(0,np.size(subjects))]


QELT_GM_abs=np.array(GM_glx_abs_all)
QELT_WM_abs=np.array(WM_glx_abs_all)

QELT_GM_glc6_tCr=np.array(GM_glc6_tCr_all)
QELT_WM_glc6_tCr=np.array(WM_glc6_tCr_all)

QELT_GM_drop=QELT_GM_abs[:,0]-QELT_GM_abs[:,13]
QELT_WM_drop=QELT_WM_abs[:,0]-QELT_WM_abs[:,13]

DMI_GM_Increase=GM_glx_abs_2H_all[:,8]
DMI_WM_Increase=WM_glx_abs_2H_all[:,8]

stats.ttest_rel(QELT_GM_drop,DMI_GM_Increase)
stats.ttest_rel(QELT_WM_drop,DMI_WM_Increase)


QELT_GM_tau=np.array(GM_glc6_expfit_ind)[:,1]
QELT_WM_tau=np.array(WM_glc6_expfit_ind)[:,1]


DMI_GM_tau=np.array(GM_glc_2H_expfit)[:,1]
DMI_WM_tau=np.array(WM_glc_2H_expfit)[:,1]

DMI_GM_Glc_Increase=GM_glc_abs_2H_all[:,8]
DMI_WM_Glc_Increase=WM_glc_abs_2H_all[:,8]

stats.ttest_rel(GM_QELT_glx_slopes,GM_DMI_glx_slopes)
stats.ttest_rel(WM_QELT_glx_slopes,WM_DMI_glx_slopes)


###### QELT correlation
QELT_GM_abs_sorted=QELT_GM_abs.flatten()
QELT_WM_abs_sorted=QELT_WM_abs.flatten()

QELT_GM_glc6_tCr=QELT_GM_glc6_tCr.flatten()
QELT_WM_glc6_tCr=QELT_WM_glc6_tCr.flatten()

time_sorted_1H=np.array([subject_time_1H+7 for x in np.arange(0,5)]).flatten()

stats.linregress(time_sorted_1H,QELT_GM_abs_sorted)
stats.linregress(time_sorted_1H,QELT_WM_abs_sorted)

stats.linregress(time_sorted_1H,QELT_GM_glc6_tCr)
stats.linregress(time_sorted_1H,QELT_WM_glc6_tCr)

###### DMI correlation

DMI_GM_glx_abs_sorted=[]
DMI_WM_glx_abs_sorted=[]

[[DMI_GM_glx_abs_sorted.append(GM_glx_abs_2H_all[y][x]) for x in np.arange(0,9)] for y in np.arange(0,1)]
[[DMI_GM_glx_abs_sorted.append(GM_glx_abs_2H_all[y][x]) for x in np.arange(0,10)] for y in np.arange(1,5)]

[[DMI_WM_glx_abs_sorted.append(WM_glx_abs_2H_all[y][x]) for x in np.arange(0,9)] for y in np.arange(0,1)]
[[DMI_WM_glx_abs_sorted.append(WM_glx_abs_2H_all[y][x]) for x in np.arange(0,10)] for y in np.arange(1,5)]


DMI_GM_glc_abs_sorted=[]
DMI_WM_glc_abs_sorted=[]

[[DMI_GM_glc_abs_sorted.append(GM_glc_abs_2H_all[y][x]) for x in np.arange(0,9)] for y in np.arange(0,1)]
[[DMI_GM_glc_abs_sorted.append(GM_glc_abs_2H_all[y][x]) for x in np.arange(0,10)] for y in np.arange(1,5)]

[[DMI_WM_glc_abs_sorted.append(WM_glc_abs_2H_all[y][x]) for x in np.arange(0,9)] for y in np.arange(0,1)]
[[DMI_WM_glc_abs_sorted.append(WM_glc_abs_2H_all[y][x]) for x in np.arange(0,10)] for y in np.arange(1,5)]




subject_time_2H_sorted=[]
[[subject_time_2H_sorted.append(subject_time_2H[y][x]) for x in np.arange(0,9)] for y in np.arange(0,1)]
[[subject_time_2H_sorted.append(subject_time_2H[y][x]) for x in np.arange(0,10)] for y in np.arange(1,5)]


stats.linregress(subject_time_2H_sorted,DMI_GM_glx_abs_sorted)
stats.linregress(subject_time_2H_sorted,DMI_WM_glx_abs_sorted)


stats.linregress(subject_time_2H_sorted,DMI_GM_glc_abs_sorted)
stats.linregress(subject_time_2H_sorted,DMI_WM_glc_abs_sorted)


time_fit_plot_1H=np.arange(3,64);
time_fit_plot_2H=np.arange(8,75);
GM_glc_2H_avg_expfit=fit(exp_increase,subject_time_2H[1],np.nanmean(GM_glc_abs_2H_all,0),[np.nanmean(GM_glc_abs_2H_all[:,9]),20,1,0])
WM_glc_2H_avg_expfit=fit(exp_increase,subject_time_2H[1],np.nanmean(WM_glc_abs_2H_all,0),[np.nanmean(WM_glc_abs_2H_all[:,9]),20,1,0])
plot_GM_glc_2H_exp_fit=exp_increase(time_fit_plot_2H,GM_glc_2H_avg_expfit[0][0],GM_glc_2H_avg_expfit[0][1],GM_glc_2H_avg_expfit[0][2],GM_glc_2H_avg_expfit[0][3]);
plot_WM_glc_2H_exp_fit=exp_increase(time_fit_plot_2H,WM_glc_2H_avg_expfit[0][0],WM_glc_2H_avg_expfit[0][1],WM_glc_2H_avg_expfit[0][2],WM_glc_2H_avg_expfit[0][3]);

##### Figure 1

plt.figure(1)
plt.errorbar(subject_time_1H+7,np.mean(GM_glx_abs_all,0),yerr=np.std(GM_glx_abs_all,0),label='GM: slope = '+str(np.round(GM_glx_linreg[0],4))+' mM/min',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.mean(WM_glx_abs_all,0),yerr=np.std(WM_glx_abs_all,0),label='WM: slope = '+str(np.round(WM_glx_linreg[0],4))+' mM/min',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

GM_glx_linplot=(subject_time_1H+7)*GM_glx_linreg[0]+GM_glx_linreg[1]
WM_glx_linplot=(subject_time_1H+7)*WM_glx_linreg[0]+WM_glx_linreg[1]
plt.plot(subject_time_1H+7,GM_glx_linplot,color='blue')
plt.plot(subject_time_1H+7,WM_glx_linplot,color='red')
plt.xlim(0,65)
plt.text(20,5.5,'GM drop: '+str(np.round(GM_glx_abs_avg[0]-GM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(GM_glx_abs_drop_sd,2))+' mM')
plt.text(20,5,'WM drop: '+str(np.round(WM_glx_abs_avg[0]-WM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(WM_glx_abs_drop_sd,2)) + ' mM')
plt.legend()
plt.title('Glutamate+Glutamine time course')
plt.ylabel('metabolite concentration [mM]')
plt.xlabel('time [min]')
plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/qelt_glx.pdf')



# ##### Figure 2

# plt.figure(2)
# plt.errorbar(subject_time_1H+5,np.mean(GM_glx_tCr_all,0),yerr=np.std(GM_glx_tCr_all,0),color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
# plt.errorbar(subject_time_1H+5,np.mean(WM_glx_tCr_all,0),yerr=np.std(WM_glx_tCr_all,0),color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

# #GM_glx_linplot=(subject_time_1H+5)*GM_glx_linreg[0]+GM_glx_linreg[1]
# #WM_glx_linplot=(subject_time_1H+5)*WM_glx_linreg[0]+WM_glx_linreg[1]
# #plt.plot(subject_time_1H+5,GM_glx_linplot,color='blue')
# #plt.plot(subject_time_1H+5,WM_glx_linplot,color='red')
# plt.xlim(0,65)
# #plt.text(20,5.5,'GM drop: '+str(np.round(GM_glx_abs_avg[0]-GM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(GM_glx_abs_drop_sd,2))+' mM')
# #plt.text(20,5,'WM drop: '+str(np.round(WM_glx_abs_avg[0]-WM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(WM_glx_abs_drop_sd,2)) + ' mM')
# #plt.legend()
# plt.title('Glutamate+Glutamine time course')
# plt.ylabel('metabolite ratio [/tCr]')
# plt.xlabel('time [min]')
# plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/qelt_glx_tCr.pdf')



GM_glx_2H_linreg=stats.linregress(subject_time_2H[1],np.nanmean(GM_glx_abs_2H_all,0))
WM_glx_2H_linreg=stats.linregress(subject_time_2H[1],np.nanmean(WM_glx_abs_2H_all,0))



##### Figure 2


plt.figure(2)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_glx_abs_2H_all,0),yerr=np.nanstd(GM_glx_abs_2H_all,0),label='GM: slope = '+str(np.round(GM_glx_2H_linreg[0],4))+ ' mM/min',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(WM_glx_abs_2H_all,0),yerr=np.nanstd(WM_glx_abs_2H_all,0),label='WM: slope = '+str(np.round(WM_glx_2H_linreg[0],4))+ ' mM/min',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)


GM_glx_2H_linplot=(subject_time_2H[1])*GM_glx_2H_linreg[0]+GM_glx_2H_linreg[1]
WM_glx_2H_linplot=(subject_time_2H[1])*WM_glx_2H_linreg[0]+WM_glx_2H_linreg[1]
plt.plot(subject_time_2H[1],GM_glx_2H_linplot,color='blue')
plt.plot(subject_time_2H[1],WM_glx_2H_linplot,color='red')
plt.text(10,1,'GM increase: '+str(np.round(GM_glx_abs_2H_avg[-2],2))+'$\pm$'+str(np.round(GM_glx_abs_2H_inc_sd,2))+' mM')
plt.text(10,0.9,'WM increase: '+str(np.round(WM_glx_abs_2H_avg[-2],2))+'$\pm$'+str(np.round(WM_glx_abs_2H_inc_sd,2)) +' mM')
plt.title('Glutamate+Glutamine time course')
plt.legend()
plt.xlim(0,75)
plt.ylim(0,2)
plt.ylabel('metabolite concentration [mM]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/dmi_glx.pdf')


##### Figure 3




GM_glc6_avg_expfit=fit(exp_decrease,subject_time_1H+7,np.nanmean(GM_glc6_tCr_all,0),[np.nanmean(GM_glc6_tCr_all,0)[0],20,np.nanmean(GM_glc6_tCr_all,0)[13]])
WM_glc6_avg_expfit=fit(exp_decrease,subject_time_1H+7,np.nanmean(WM_glc6_tCr_all,0),[np.nanmean(WM_glc6_tCr_all,0)[0],20,np.nanmean(WM_glc6_tCr_all,0)[13]])
plot_GM_glc6_exp_fit=exp_decrease(time_fit_plot_1H,GM_glc6_avg_expfit[0][0],GM_glc6_avg_expfit[0][1],GM_glc6_avg_expfit[0][2]);
plot_WM_glc6_exp_fit=exp_decrease(time_fit_plot_1H,WM_glc6_avg_expfit[0][0],WM_glc6_avg_expfit[0][1],WM_glc6_avg_expfit[0][2]);

plt.figure(3)
plt.errorbar(subject_time_1H+7,np.mean(GM_glc6_tCr_all,0),yerr=np.std(GM_glc6_tCr_all,0),color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.mean(WM_glc6_tCr_all,0),yerr=np.std(WM_glc6_tCr_all,0),color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.plot(time_fit_plot_1H,plot_GM_glc6_exp_fit,color='blue',label='tau = '+str(np.round(np.mean(np.array(GM_glc6_expfit_ind)[:,1]),2))+ '$\pm$' + str(np.round(np.std(np.array(GM_glc6_expfit_ind)[:,1]),2)) +' min')
plt.plot(time_fit_plot_1H,plot_WM_glc6_exp_fit,color='red',label='tau = '+str(np.round(np.mean(np.array(WM_glc6_expfit_ind)[:,1]),2))+ '$\pm$' + str(np.round(np.std(np.array(WM_glc6_expfit_ind)[:,1]),2)) +' min')
plt.xlim(0,65)
#plt.text(20,5.5,'GM drop: '+str(np.round(GM_glx_abs_avg[0]-GM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(GM_glx_abs_drop_sd,2))+' mM')
#plt.text(20,5,'WM drop: '+str(np.round(WM_glx_abs_avg[0]-WM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(WM_glx_abs_drop_sd,2)) + ' mM')
plt.legend()
plt.title('Glucose6 time course')
plt.ylabel('metabolite ratio [/tCr]')
plt.xlabel('time [min]')
plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/qelt_glc6_tCr.pdf')



##### Figure 3


plot_GM_glc6_exp_fit_ind=[]
[plot_GM_glc6_exp_fit_ind.append(exp_decrease(time_fit_plot_1H,GM_glc6_expfit_ind[x][0],GM_glc6_expfit_ind[x][1],GM_glc6_expfit_ind[x][2])) for x in np.arange(0,np.size(subjects))]

plot_WM_glc6_exp_fit_ind=[]
[plot_WM_glc6_exp_fit_ind.append(exp_decrease(time_fit_plot_1H,WM_glc6_expfit_ind[x][0],WM_glc6_expfit_ind[x][1],WM_glc6_expfit_ind[x][2])) for x in np.arange(0,np.size(subjects))]




GM_glc6_avg_expfit=fit(exp_decrease,subject_time_1H+7,np.nanmean(GM_glc6_tCr_all,0),[np.nanmean(GM_glc6_tCr_all,0)[0],20,np.nanmean(GM_glc6_tCr_all,0)[13]])
WM_glc6_avg_expfit=fit(exp_decrease,subject_time_1H+7,np.nanmean(WM_glc6_tCr_all,0),[np.nanmean(WM_glc6_tCr_all,0)[0],20,np.nanmean(WM_glc6_tCr_all,0)[13]])
plot_GM_glc6_exp_fit=exp_decrease(time_fit_plot_1H,GM_glc6_avg_expfit[0][0],GM_glc6_avg_expfit[0][1],GM_glc6_avg_expfit[0][2]);
plot_WM_glc6_exp_fit=exp_decrease(time_fit_plot_1H,WM_glc6_avg_expfit[0][0],WM_glc6_avg_expfit[0][1],WM_glc6_avg_expfit[0][2]);

plt.figure(4)
[plt.plot(subject_time_1H+7,GM_glc6_tCr_all[x],color='blue',marker='o',ls='none') for x in np.arange(0,np.size(subjects))]
[plt.plot(subject_time_1H+7,WM_glc6_tCr_all[x],color='red',marker='o',ls='none') for x in np.arange(0,np.size(subjects))]

[plt.plot(time_fit_plot_1H,plot_GM_glc6_exp_fit_ind[x],color='blue',label='tau = '+str(np.round(GM_glc6_expfit_ind[x][1],2))+ ' min') for x in np.arange(0,np.size(subjects))]
[plt.plot(time_fit_plot_1H,plot_WM_glc6_exp_fit_ind[x],color='red',label='tau = '+str(np.round(WM_glc6_expfit_ind[x][1],2))+ ' min') for x in np.arange(0,np.size(subjects))]
plt.xlim(0,65)
#plt.text(20,5.5,'GM drop: '+str(np.round(GM_glx_abs_avg[0]-GM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(GM_glx_abs_drop_sd,2))+' mM')
#plt.text(20,5,'WM drop: '+str(np.round(WM_glx_abs_avg[0]-WM_glx_abs_avg[13],2))+'$\pm$'+str(np.round(WM_glx_abs_drop_sd,2)) + ' mM')
plt.legend()
plt.title('Glucose6 time course')
plt.ylabel('metabolite ratio [/tCr]')
plt.xlabel('time [min]')
plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/qelt_glc6_tCr_individual.pdf')



##### Figure 5

plt.figure(5)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_glc_abs_2H_all,0),yerr=np.nanstd(GM_glc_abs_2H_all,0),color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(WM_glc_abs_2H_all,0),yerr=np.nanstd(WM_glc_abs_2H_all,0),color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.plot(time_fit_plot_2H,plot_GM_glc_2H_exp_fit,color='blue',label='tau = '+str(np.round(np.mean(np.array(GM_glc_2H_expfit)[:,1]),2))+ '$\pm$' + str(np.round(np.std(np.array(GM_glc_2H_expfit)[:,1]),2)) + ' min')
plt.plot(time_fit_plot_2H,plot_WM_glc_2H_exp_fit,color='red',label='tau = '+str(np.round(np.mean(np.array(WM_glc_2H_expfit)[:,1]),2))+ '$\pm$' + str(np.round(np.std(np.array(WM_glc_2H_expfit)[:,1]),2)) + ' min')

plt.text(35,0.2,'GM increase: '+str(np.round(GM_glc_abs_2H_avg[-1],2))+'$\pm$'+str(np.round(GM_glc_abs_2H_inc_sd,2))+' mM')
plt.text(35,0.1,'WM increase: '+str(np.round(WM_glc_abs_2H_avg[-1],2))+'$\pm$'+str(np.round(WM_glc_abs_2H_inc_sd,2)) +' mM')
plt.title('Glucose time course')
plt.legend()
plt.xlim(0,75)
plt.ylim(0,2)
plt.ylabel('metabolite concentration [mM]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/dmi_glc.pdf')


##### Figure 6
plot_GM_glc_2H_exp_fit_individual=[]
[plot_GM_glc_2H_exp_fit_individual.append(exp_increase(time_fit_plot_2H,GM_glc_2H_expfit[x][0],GM_glc_2H_expfit[x][1],GM_glc_2H_expfit[x][2],GM_glc_2H_expfit[x][3])) for x in np.arange(0,np.size(subjects_DMI))]

plot_WM_glc_2H_exp_fit_individual=[]
[plot_WM_glc_2H_exp_fit_individual.append(exp_increase(time_fit_plot_2H,WM_glc_2H_expfit[x][0],WM_glc_2H_expfit[x][1],WM_glc_2H_expfit[x][2],WM_glc_2H_expfit[x][3])) for x in np.arange(0,np.size(subjects_DMI))]


plt.figure(6)
[plt.plot(subject_time_2H[1],GM_glc_abs_2H_all[x],color='blue',marker='o',ls='none')for x in np.arange(0,np.size(subjects_DMI))]
[plt.plot(subject_time_2H[1],WM_glc_abs_2H_all[x],color='red',marker='o',ls='none') for x in np.arange(0,np.size(subjects_DMI))]

[plt.plot(time_fit_plot_2H,plot_GM_glc_2H_exp_fit_individual[x],color='blue',label='tau = '+str(np.round(GM_glc_2H_expfit[x][1],2))+' min') for x in np.arange(0,np.size(subjects_DMI))]
[plt.plot(time_fit_plot_2H,plot_WM_glc_2H_exp_fit_individual[x],color='red',label='tau = '+str(np.round(WM_glc_2H_expfit[x][1],2))+' min') for x in np.arange(0,np.size(subjects_DMI))]

#plt.text(5,0.8,'GM increase: '+str(np.round(GM_glc_abs_2H_avg[-1],2))+'$\pm$'+str(np.round(GM_glc_abs_2H_inc_sd,2))+' mM')
#plt.text(5,0.7,'WM increase: '+str(np.round(WM_glc_abs_2H_avg[-1],2))+'$\pm$'+str(np.round(WM_glc_abs_2H_inc_sd,2)) +' mM')
plt.title('Glucose time course')
plt.legend()
plt.xlim(0,75)
plt.ylim(-0.1,2)
plt.ylabel('metabolite concentration [mM]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/dmi_glc_individual.pdf')


##### Figure 7


plt.figure(7)

#GM_glx_corr=np.array(GM_glx_abs_all).flatten()
#WM_glx_corr=np.array(WM_glx_abs_all).flatten()

#GM_glx_2H_corr=np.array(GM_glx_abs_2H_interpolated).flatten()
#WM_glx_2H_corr=np.array(WM_glx_abs_2H_interpolated).flatten()


GM_glx_abs_2H_interpolated_sorted=[[GM_glx_abs_2H_interpolated[x][y] for x in np.arange(0,np.size(subjects_DMI))] for y in np.arange(0,14)]
WM_glx_abs_2H_interpolated_sorted=[[WM_glx_abs_2H_interpolated[x][y] for x in np.arange(0,np.size(subjects_DMI))] for y in np.arange(0,14)]
GM_glx_abs_all_sorted=[[GM_glx_abs_all[x][y] for x in np.arange(0,np.size(subjects))] for y in np.arange(0,14)]
WM_glx_abs_all_sorted=[[WM_glx_abs_all[x][y] for x in np.arange(0,np.size(subjects))] for y in np.arange(0,14)]

GM_glx_2H_corr=np.array(GM_glx_abs_2H_interpolated_sorted).flatten()
WM_glx_2H_corr=np.array(WM_glx_abs_2H_interpolated_sorted).flatten()

GM_glx_corr=np.array(GM_glx_abs_all_sorted).flatten()
WM_glx_corr=np.array(WM_glx_abs_all_sorted).flatten()

GM_corr_regress=stats.linregress(GM_glx_2H_corr,GM_glx_corr)
WM_corr_regress=stats.linregress(WM_glx_2H_corr,WM_glx_corr)

GM_regress_fit=GM_glx_2H_corr*GM_corr_regress[0]+GM_corr_regress[1]
WM_regress_fit=WM_glx_2H_corr*WM_corr_regress[0]+WM_corr_regress[1]

#[plt.plot(GM_glx_abs_2H_interpolated[x],GM_glx_abs_all[x],color='blue',marker='o',ls='none') for x in np.arange(0,5)]
#[plt.plot(WM_glx_abs_2H_interpolated[x],WM_glx_abs_all[x],color='red',marker='o',ls='none') for x in np.arange(0,5)]

plt.plot(GM_glx_2H_corr,GM_glx_corr,color='blue',marker='o',ls='none',label='GM')
plt.plot(WM_glx_2H_corr,WM_glx_corr,color='red',marker='o',ls='none',label='WM')
plt.text(0,10,'GM: r= '+str(np.round(GM_corr_regress[2],2))+' p < 0.001',color='blue')
plt.text(0,9.5,'WM: r= '+str(np.round(WM_corr_regress[2],2))+' p < 0.001',color='red')
plt.plot(GM_glx_2H_corr,GM_regress_fit,color='blue')
plt.plot(WM_glx_2H_corr,WM_regress_fit,color='red')

plt.xlabel('metabolite concentration [mM]')
plt.ylabel('metabolite concentration [mM]')
plt.legend()
plt.title('1H vs 2H correlation')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/correlation_glx.pdf')


# ##### Figure 8

# plt.figure(8)


# GM_glx_abs_2H_avg_linreg=stats.linregress(subject_time_2H[1],GM_glx_abs_2H_avg)
# WM_glx_abs_2H_avg_linreg=stats.linregress(subject_time_2H[1],WM_glx_abs_2H_avg)

# GM_glx_abs_2H_avg_interpolated=(subject_time_1H+5)*GM_glx_abs_2H_avg_linreg[0]+GM_glx_abs_2H_avg_linreg[1]
# WM_glx_abs_2H_avg_interpolated=(subject_time_1H+5)*WM_glx_abs_2H_avg_linreg[0]+WM_glx_abs_2H_avg_linreg[1]


# GM_glx_corr_avg=stats.linregress(GM_glx_abs_2H_avg_interpolated,GM_glx_abs_avg)
# WM_glx_corr_avg=stats.linregress(WM_glx_abs_2H_avg_interpolated,WM_glx_abs_avg)

# GM_glx_corr_avg_linplot=GM_glx_abs_2H_avg_interpolated*GM_glx_corr_avg[0]+GM_glx_corr_avg[1]
# WM_glx_corr_avg_linplot=WM_glx_abs_2H_avg_interpolated*WM_glx_corr_avg[0]+WM_glx_corr_avg[1]

# plt.plot(GM_glx_abs_2H_avg_interpolated,GM_glx_abs_avg,color='blue',marker='o',ls='none',label='GM')
# plt.plot(WM_glx_abs_2H_avg_interpolated,WM_glx_abs_avg,color='red',marker='o',ls='none',label='WM')
# plt.text(0.1,10.5,'GM: r= '+str(np.round(GM_glx_corr_avg[2],2))+' p < 0.001',color='blue')
# plt.text(0.1,10,'WM: r= '+str(np.round(WM_glx_corr_avg[2],2))+' p < 0.001',color='red')
# plt.plot(GM_glx_abs_2H_avg_interpolated,GM_glx_corr_avg_linplot,color='blue')
# plt.plot(WM_glx_abs_2H_avg_interpolated,WM_glx_corr_avg_linplot,color='red')
# plt.xlabel('metabolite concentration [mM]')
# plt.ylabel('metabolite concentration [mM]')
# plt.legend()
# plt.title('1H vs 2H correlation')

# plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/correlation_avg.pdf')



### Figure 8
plt.figure(8)



GM_glc_abs_2H_interpolated_sorted=[[GM_glc_abs_2H_interpolated[x][y] for x in np.arange(0,np.size(subjects_DMI))] for y in np.arange(0,14)]
WM_glc_abs_2H_interpolated_sorted=[[WM_glc_abs_2H_interpolated[x][y] for x in np.arange(0,np.size(subjects_DMI))] for y in np.arange(0,14)]
GM_glc6_tCr_all_sorted=[[GM_glc6_tCr_all[x][y] for x in np.arange(0,np.size(subjects))] for y in np.arange(0,14)]
WM_glc6_tCr_all_sorted=[[WM_glc6_tCr_all[x][y] for x in np.arange(0,np.size(subjects))] for y in np.arange(0,14)]

GM_glc_2H_corr=np.array(GM_glc_abs_2H_interpolated_sorted).flatten()
WM_glc_2H_corr=np.array(WM_glc_abs_2H_interpolated_sorted).flatten()

GM_glc6_corr=np.array(GM_glc6_tCr_all_sorted).flatten()
WM_glc6_corr=np.array(WM_glc6_tCr_all_sorted).flatten()

GM_glc6_corr_regress=stats.linregress(GM_glc_2H_corr,GM_glc6_corr)
WM_glc6_corr_regress=stats.linregress(WM_glc_2H_corr,WM_glc6_corr)

GM_glc6_regress_fit=GM_glc_2H_corr*GM_glc6_corr_regress[0]+GM_glc6_corr_regress[1]
WM_glc6_regress_fit=WM_glc_2H_corr*WM_glc6_corr_regress[0]+WM_glc6_corr_regress[1]

#[plt.plot(GM_glx_abs_2H_interpolated[x],GM_glx_abs_all[x],color='blue',marker='o',ls='none') for x in np.arange(0,5)]
#[plt.plot(WM_glx_abs_2H_interpolated[x],WM_glx_abs_all[x],color='red',marker='o',ls='none') for x in np.arange(0,5)]

plt.plot(GM_glc_2H_corr,GM_glc6_corr,color='blue',marker='o',ls='none',label='GM')
plt.plot(WM_glc_2H_corr,WM_glc6_corr,color='red',marker='o',ls='none',label='WM')
plt.text(0,0.48,'GM: r= '+str(np.round(GM_glc6_corr_regress[2],2))+' p < 0.001',color='blue')
plt.text(0,0.45,'WM: r= '+str(np.round(WM_glc6_corr_regress[2],2))+' p < 0.001',color='red')
plt.plot(GM_glc_2H_corr,GM_glc6_regress_fit,color='blue')
plt.plot(WM_glc_2H_corr,WM_glc6_regress_fit,color='red')

plt.xlabel('metabolite concentration [mM]')
plt.ylabel('metabolite concentration [ratio /tCr]')
plt.legend()
plt.title('1H vs 2H correlation')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/correlation_glc.pdf')


##### Figure 9

plt.figure(9)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_water_2H_all,0),yerr=np.nanstd(GM_water_2H_all,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(WM_water_2H_all,0),yerr=np.nanstd(WM_water_2H_all,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('D2O time course')
plt.legend()
plt.xlim(0,75)
#plt.ylim(0,1)
plt.ylabel('metabolite concentration [a.u.]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/dmi_water.pdf')




##### Figure 10

plt.figure(10)
plt.errorbar(subject_time_1H+7,np.nanmean(GM_glx_o_sd_all_points,0),yerr=np.nanstd(GM_glx_o_sd_all_points,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.nanmean(WM_glx_o_sd_all_points,0),yerr=np.nanstd(WM_glx_o_sd_all_points,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses QELT glx')
plt.legend()
plt.ylim(0,100)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_QELT_glx.pdf')

##### Figure 11

plt.figure(11)
plt.errorbar(subject_time_1H+7,np.nanmean(GM_glc6_o_sd_all_points,0),yerr=np.nanstd(GM_glc6_o_sd_all_points,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.nanmean(WM_glc6_o_sd_all_points,0),yerr=np.nanstd(WM_glc6_o_sd_all_points,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses QELT glc6')
plt.legend()
plt.ylim(0,100)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_QELT_glc.pdf')

##### Figure 12

plt.figure(12)
plt.errorbar(subject_time_1H+7,np.nanmean(GM_QELT_SNR,0),yerr=np.nanstd(GM_QELT_SNR,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.nanmean(WM_QELT_SNR,0),yerr=np.nanstd(WM_QELT_SNR,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('Time courses QELT SNR')
plt.legend()
#plt.xlim(0,75)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/QELT_SNR.pdf')




##### Figure 13

plt.figure(13)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_glx_sd_2H_all,0),yerr=np.nanstd(GM_glx_sd_2H_all,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(WM_glx_sd_2H_all,0),yerr=np.nanstd(WM_glx_sd_2H_all,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses DMI glx')
plt.legend()
plt.ylim(0,100)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_DMI_glx.pdf')




##### Figure 14

plt.figure(14)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_glc_sd_2H_all,0),yerr=np.nanstd(GM_glc_sd_2H_all,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(WM_glc_sd_2H_all,0),yerr=np.nanstd(WM_glc_sd_2H_all,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses DMI glc')
plt.legend()
plt.ylim(0,100)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_DMI_glc.pdf')

##### Figure 15

plt.figure(15)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_DMI_SNR_all,0),yerr=np.nanstd(GM_DMI_SNR_all,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(WM_DMI_SNR_all,0),yerr=np.nanstd(WM_DMI_SNR_all,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('Time courses DMI SNR')
plt.legend()
#plt.xlim(0,75)
#plt.ylim(0,1)
plt.ylabel('SNR ')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/QELT_SNR.pdf')




##### Figure 16

plt.figure(16)
plt.errorbar(subject_time_1H+7,np.nanmean(GM_tCr_sd_all_points,0),yerr=np.nanstd(GM_tCr_sd_all_points,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.nanmean(WM_tCr_sd_all_points,0),yerr=np.nanstd(WM_tCr_sd_all_points,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses QELT tCr')
plt.legend()
plt.ylim(0,100)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_QELT_tCr.pdf')



##### Figure 17

plt.figure(17)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_water_sd_2H_all,0),yerr=np.nanstd(GM_water_sd_2H_all,0),label='GM',color='blue',marker='o',ls='none',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(WM_water_sd_2H_all,0),yerr=np.nanstd(WM_water_sd_2H_all,0),label='WM',color='red',marker='o',ls='none',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses DMI water')
plt.legend()
plt.ylim(0,100)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_DMI_water.pdf')


##### Figure 18

plt.figure(18)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_WM_water_sd_2H_all,0),yerr=np.nanstd(GM_WM_water_sd_2H_all,0),label='water',marker='o',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_WM_glc_sd_2H_all,0),yerr=np.nanstd(GM_WM_glc_sd_2H_all,0),label='glucose',marker='o',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_2H[1],np.nanmean(GM_WM_glx_sd_2H_all,0),yerr=np.nanstd(GM_WM_glx_sd_2H_all,0),label='glutamate+glutamine',marker='o',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses DMI ')
plt.legend()
plt.ylim(0,205)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_DMI.pdf')


##### Figure 19

plt.figure(19)
plt.errorbar(subject_time_1H+7,np.nanmean(GM_WM_tCr_sd_all,0),yerr=np.nanstd(GM_WM_tCr_sd_all,0),label='tCr',marker='o',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.nanmean(GM_WM_glc6_o_sd_all,0),yerr=np.nanstd(GM_WM_glc6_o_sd_all,0),label='glucose',marker='o',elinewidth=0.5,capsize=2)
plt.errorbar(subject_time_1H+7,np.nanmean(GM_WM_glx_o_sd_all,0),yerr=np.nanstd(GM_WM_glx_o_sd_all,0),label='glutamate+glutamine',marker='o',elinewidth=0.5,capsize=2)

plt.title('CRLB time courses QELT')
plt.legend()
plt.ylim(0,100)
#plt.ylim(0,1)
plt.ylabel('CRLB [%]')
plt.xlabel('time [min]')

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/CRLBs_QELT.pdf')

######### Blood glucose

blood_glc=[]
blood_glc_time=[]
subject_names=['S1','S2','S3','S4','S5']
S1_glc=[80,101,91,88,84,90]
S1_time=[0,17,36,51,63,100]

S2_glc=[76,109,130,110,112,86]
S2_time=[0,19,32,50,63,101]

S3_glc=[97,92,108,120,141,132]
S3_time=[0,15,34,47,60,98]

S4_glc=[90,102,164,149,147,119]
S4_time=[0,17,36,51,63,100]

S5_glc=[85,115,135,108,109,105]
S5_time=[0,18,32,50,62,99]

blood_glc.append(S1_glc)
blood_glc.append(S2_glc)
blood_glc.append(S3_glc)
blood_glc.append(S4_glc)
blood_glc.append(S5_glc)

blood_glc_time.append(S1_time)
blood_glc_time.append(S2_time)
blood_glc_time.append(S3_time)
blood_glc_time.append(S4_time)
blood_glc_time.append(S5_time)

blood_glc_mean=np.mean(blood_glc,0)
blood_glc_std=np.std(blood_glc,0)
blood_glc_time_mean=np.mean(blood_glc_time,0)
plt.figure('blood glucose')

#[plt.plot(blood_glc_time[x],blood_glc[x],label=subject_names[x],marker='o') for x in np.arange(0,np.size(subject_names))]
plt.errorbar(blood_glc_time_mean,blood_glc_mean,yerr=blood_glc_std,label='average blood glucose over subjects',color='orange',ls='none',marker='o',elinewidth=1,capsize=3)
plt.plot(blood_glc_time_mean,blood_glc_mean,color='orange')
plt.legend()
plt.xlabel('time / [min]')
plt.ylabel('blood glucose [mg/dl]')
plt.ylim(0,160)

plt.savefig('/Volumes/exp_mri_rad_d_mrsbrain/lab/Measurement_Data/7T_DMI/plots/blood_glucose.pdf')





